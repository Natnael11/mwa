const express = require("express");
// const controllerGames = require("../controllers/games.controller");
// // const controllerPublishers = require("../controllers/publisher.controller");
// // const controllerReview = require("../controllers/review.controller");
const controllerTravel = require("../controllers/travel.controller");
const controllerPlaceToVisit = require("../controllers/placeToVisit.controller");

const router = express.Router();

// travel


router
  .route("/travel")
  .get(controllerTravel.travelGetAll)
  .post(controllerTravel.travelAddOne);

router.route("/travel/:travelId")
      .get(controllerTravel.travelGetOne)
      .put(controllerTravel.travelFullUpdateOne)
      .patch(controllerTravel.TravelPartialUpdateOne)
      .delete(controllerTravel.travelDeleteOne);

// place to visit

router.route("/travel/:travelId/placeToVisit/:placeToVisitId")
      .get(controllerPlaceToVisit.placeToVisitGetOne)
      .put(controllerPlaceToVisit.placeToVisitFullUpdateOne)
      .delete(controllerPlaceToVisit.placeToVisitDeleteOne);

router.route("/travel/:travleId/placeToVisit")
       .post(controllerPlaceToVisit.placeToVisitAddOne)

module.exports = router;
