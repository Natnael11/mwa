const { ReplSet } = require("mongodb");
const mongoose = require("mongoose");
const Game = mongoose.model("Game");

const _addReview = function(req, res, game){
    console.log("inside _addReview")
    console.log(req.body.name);
    console.log(req.body.reviews);
    console.log(req.body.date);
    game.reviews.name = req.body.name;
    game.reviews.review = req.body.reviews;
    game.reviews.date= req.body.date;
    
    game.save(function(err, game){
        console.log("upadated game ", game); 
        const response = {
            status: 200,
            message: game
          };
          if (err) {
            console.log("Error saving review");
            response.status = 500;
            response.message = err;
          }
          res.status(response.status).json(response.message);
    })
}


module.exports.reviewGetOne = function(req, res){
    console.log("GetOne review request received");
    const gameId = req.params.gameId;
    Game.findById(gameId).select("reviews").exec(function(err, game){
        res.status(200).json(game.reviews);
    });
}
module.exports.reviewAddOne = function (req, res) {
    console.log("POST new reviews");
    console.log(req.body);
    const gameId = req.params.gameId;
    Game.findById(gameId).exec(function(err, game){
        const response = {
            status: 200,
            message: game,
          };
          if (err) {
            console.log("Error creating game");
            response.status = 500;
            response.message = err;
          } else if(!game){
              console.log("Error creating reviews");
              response.status = 404;
              response.message = {"message": "Game id not found"};
          }
          if(game){
              console.log("Game is ", game);
              _addReview(req, res, game);
          }else{
            res.status(response.status).json(response.message);
          }          
        }     
  )};
  module.exports.reviewFullUpdateOne = function(req, res){
    console.log("GetOne reviews request received");
    const gameId = req.params.gameId;
    Game.findById(gameId).exec(function(err, game){
        if(err){
            res.status(500).message(err);
        } else if(!game){
            res.status(404).json({"message": "Game ID  not found"});
        }
        if(game){
            game.reviews.name = req.body.name;
            game.reviews.review = req.body.reviews;
            game.reviews.date = req.body.date;
            game.save(function(err, updatedGame){
                if(err){
                    res.status(500).json(err);
                }else{
                    res.status(204).json(updatedGame.reviews);
                }
            });
        }
    });
}

module.exports.reviewDeleteOne = function(req, res){
    console.log("DeleteOne review request received");
    const gameId = req.params.gameId;
    Game.findById(gameId).exec(function(err, game){
        if(err){
            res.status(500).message(err);
        } else if(!game){
            res.status(404).json({"message": "Game ID  not found"});
        }
        if(game){
            game.reviews.remove();
            game.save(function(err, updatedGame){
                if(err){
                    res.status(500).json(err);
                }else{
                    res.status(204).json(updatedGame.reviews);
                }
            });
        }
    });
}