angular.module("meanTravel").controller("TravelsController", TravelsController);

function TravelsController(TravelsDataFactory) {
    const vm = this;
    vm.title = "Mean Travel App"
    TravelsDataFactory.getAll().then(function(response) {
        vm.travels=response;
    });
}