angular.module("meanTravel").controller("TravelController", TravelController);

function TravelController(TravelsDataFactory, $routeParams) {
    const vm = this;
    const travelId= $routeParams.travelId;
    TravelsDataFactory.getOne(travelId).then(function (response) {
        vm.travel = response;
    });
}
