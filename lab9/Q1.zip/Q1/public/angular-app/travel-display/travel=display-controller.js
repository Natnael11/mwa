angular.module("meanTravel").controller("TravelController", TravelController);

function TravelController(TravelsDataFactory, $routeParams) {
    const vm = this;
    const travelId= $routeParams.travelId;
    TravelsDataFactory.getOne(travelId).then(function (response) {
        vm.travel = response;
    });

    vm.delete = function () {
        console.log("delete received");
        TravelsDataFactory.deleteOne(travelId)
            .then( function (response) {
                console.log("Travel deleted")
            })
            .catch( function (error) {
                console.log("Error while deleting", error)
            });
    };
}
