angular.module("meanTravel", ['ngRoute']).config(config);

function config($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl:"angular-app/travel-list/travel-list.html",
        controller: "TravelsController",
        controllerAs: "vm"
    }).when("/travel/:travelId", {
        templateUrl:"angular-app/travel-display/travel-display.html",
        controller: "TravelController",
        controllerAs: "vm"

    });
}