angular.module("meanGames").controller("GameController",  GameController);

function GameController( GamesDataFactory, $routeParams) {
    const vm = this;
    const gamesId = $routeParams.id;
    GamesDataFactory.getOne(gamesId).then(function(response) {
        vm.game=response;
    })
    
}