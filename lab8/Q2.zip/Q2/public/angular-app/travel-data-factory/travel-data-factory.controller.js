angular.module("meanTravel").factory("TravelsDataFactory", TravelsDataFactory );

function TravelsDataFactory($http) {
   return {
       getAll: getAllTravels,
       getOne: getOneTravel
   };

   function getAllTravels() {
       return $http.get("/api/travel").then(complete).catch(failed);
   }

   function getOneTravel(travelId) {
    return $http.get("/api/travel/"+travelId).then(complete).catch(failed);

   }

   function complete(response) {
     return response.data;
   }

   function failed(error) {
       return error.status.statusText;

   }
}